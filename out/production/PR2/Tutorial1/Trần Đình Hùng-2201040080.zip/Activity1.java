package Tutorial1;

public class Activity1 {
    public static void main(String[] args) {
        System.out.println("      **********      ******             **         **");
        System.out.println("           **         **    **           **         **");
        System.out.println("           **         **     **          **         **");
        System.out.println("           **         **      **         **         **");
        System.out.println("           **      ** ** **    **        ** ******* **");
        System.out.println("    **     **         **     **          **         **");
        System.out.println("     **    **         **    **           **         **");
        System.out.println("      **   **         **   **            **         **");
        System.out.println("        *****         ****               **         **");



    }

}
