package Tutorial6.Monster;

public class testMonster {
    public static void main(String[] args) {
        Monster m1 = new FireMonster("Fire dragon");
        System.out.println(m1.attack());
    }

}
