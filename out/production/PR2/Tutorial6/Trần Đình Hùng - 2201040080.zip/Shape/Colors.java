package Tutorial6.Shape;

public enum Colors {
    WHITE,
    BLACK,
    RED,
    ORANGE,
    YELLOW,
    PURPLE,
    GREEN,
    BLUE,
    BROWN
}
