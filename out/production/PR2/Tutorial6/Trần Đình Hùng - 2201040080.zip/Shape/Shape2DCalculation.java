package Tutorial6.Shape;

public interface Shape2DCalculation {

    double getArea();
    double getPerimeter();
       
}
