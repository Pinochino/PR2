package Tutorial6.Monster2D;

 abstract  public class Monster {
}
