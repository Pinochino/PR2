package Tutorial6.Monster2D;

import Tutorial6.Shape.Point2D;

public interface SpecialAbility {
    abstract void transform();
    abstract Point2D teleport();

}
