package Tutorial3;
import  java.util.Scanner;
public class Activity3 {

    public static void main(String[] args) {
        Product product1 = new Product();
        product1.input();
        product1.display();
        Product product2 = new Product();
        product2.input();
        product2.display();
    }
}
