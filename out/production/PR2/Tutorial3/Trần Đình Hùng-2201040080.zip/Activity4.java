package Tutorial3;

public class Activity4 {
    public static void main(String[] args) {
    Product p1 = new Product("Iphone", 300, 13);
    Product p2 = new Product("Ipad", 320, 13);
    p1.display();
    p2.display();
    }
}
